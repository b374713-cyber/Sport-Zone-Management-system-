// Front_end/snp/src/components/gym/GymDirectory.js
import React, { useEffect, useState } from "react";
import { Row, Col, Card, ListGroup, Badge } from "react-bootstrap";
import coachesService from "../../services/coachesService";
import membersService from "../../services/membersService";
import ProfileCoach from "./ProfileCoach";
import ProfileMember from "./ProfileMember";
import AssignCoachModal from "./modals/AssignCoachModal";
import FloatingCoachMore from "./FloatingCoachMore";

const headerGradient = "linear-gradient(90deg, #3b2a88 0%, #146b57 100%)";

export default function GymDirectory() {
  const [coaches, setCoaches] = useState([]);
  const [members, setMembers] = useState([]);
  const [selectedCoach, setSelectedCoach] = useState(null);
  const [selectedMember, setSelectedMember] = useState(null);
  const [showAssign, setShowAssign] = useState(false);

  const load = async () => {
    setCoaches(await coachesService.list());
    setMembers(await membersService.list());
  };

  useEffect(() => {
    load();
  }, []);

  const openCoach = (c) => {
    setSelectedCoach(c);
    setSelectedMember(null);
  };

  const openMember = (m) => {
    setSelectedMember(m);
    setSelectedCoach(null);
  };

  const onAssigned = async () => {
    setShowAssign(false);
    await load();
  };

  // ✅ same safe helper used for members (absolute/base64/relative)
  const buildPhotoSrc = (raw) => {
    if (!raw || String(raw).trim() === "") return null;
    const v = String(raw);

    if (v.startsWith("http") || v.startsWith("data:")) return v;
    return `http://localhost:5000/${v.replace(/^\/+/, "")}`;
  };

  return (
    <Row className="g-3">
      {/* Left pane: Coaches */}
      <Col md={4}>
        <Card className="border-0 shadow-sm">
          <Card.Header
            style={{ background: headerGradient, color: "#fff" }}
            className="d-flex justify-content-between align-items-center"
          >
            <span>👨‍🏫 Coaches</span>

            {/* ✅ small yellow "More" inside header */}
            <FloatingCoachMore
              inline
              onChanged={load}
              style={{
                background: "#f9d949",
                color: "#000",
                border: "none",
                fontWeight: 800,
                padding: "4px 12px",
                borderRadius: "999px",
                fontSize: 13,
                boxShadow: "0 4px 10px rgba(0,0,0,0.2)",
              }}
            />
          </Card.Header>

          <ListGroup variant="flush">
            {coaches.map((c) => {
              const cPhoto = buildPhotoSrc(c.photo_url);

              return (
                <ListGroup.Item
                  key={c.coach_id}
                  action
                  onClick={() => openCoach(c)}
                >
                  <div className="d-flex align-items-center">
                    <div
                      className="rounded-circle bg-secondary me-2"
                      style={{ width: 36, height: 36, overflow: "hidden" }}
                    >
                      {cPhoto ? (
                        <img
                          src={cPhoto}
                          alt=""
                          style={{
                            width: "100%",
                            height: "100%",
                            objectFit: "cover",
                          }}
                          onError={(e) =>
                            (e.currentTarget.style.display = "none")
                          }
                        />
                      ) : (
                        <span className="text-white d-block text-center">
                          👤
                        </span>
                      )}
                    </div>

                    <div className="flex-grow-1">
                      <div className="fw-semibold">{c.full_name}</div>
                      <small className="text-muted">
                        {c.specialties || ""}
                      </small>
                    </div>

                    <Badge bg="success">{c.status}</Badge>
                  </div>
                </ListGroup.Item>
              );
            })}

            {coaches.length === 0 && (
              <ListGroup.Item className="text-muted">
                No coaches found
              </ListGroup.Item>
            )}
          </ListGroup>
        </Card>
      </Col>

      {/* Middle pane: Members */}
      <Col md={4}>
        <Card className="border-0 shadow-sm">
          <Card.Header style={{ background: headerGradient, color: "#fff" }}>
            🧍 Members
          </Card.Header>

          <ListGroup variant="flush">
            {members.map((m) => {
              const mPhoto = buildPhotoSrc(m.photo_url);

              return (
                <ListGroup.Item
                  key={m.member_id}
                  action
                  onClick={() => openMember(m)}
                >
                  <div className="d-flex align-items-center">
                    <div
                      className="rounded-circle bg-secondary me-2"
                      style={{ width: 36, height: 36, overflow: "hidden" }}
                    >
                      {mPhoto ? (
                        <img
                          src={mPhoto}
                          alt=""
                          style={{
                            width: "100%",
                            height: "100%",
                            objectFit: "cover",
                          }}
                          onError={(e) =>
                            (e.currentTarget.style.display = "none")
                          }
                        />
                      ) : (
                        <span className="text-white d-block text-center">
                          🙂
                        </span>
                      )}
                    </div>

                    <div className="flex-grow-1">
                      <div className="fw-semibold">{m.full_name}</div>
                      <small className="text-muted">
                        {m.phone || "No phone"}
                      </small>
                    </div>

                    <Badge bg="primary">{m.status}</Badge>
                  </div>
                </ListGroup.Item>
              );
            })}

            {members.length === 0 && (
              <ListGroup.Item className="text-muted">
                No members found
              </ListGroup.Item>
            )}
          </ListGroup>
        </Card>
      </Col>

      {/* Right pane: Details */}
      <Col md={4}>
        {!selectedCoach && !selectedMember && (
          <Card className="border-0 shadow-sm">
            <Card.Body>Select a coach or member…</Card.Body>
          </Card>
        )}

        {selectedCoach && (
          <ProfileCoach
            coach={selectedCoach}
            onAssignClick={() => setShowAssign(true)}
          />
        )}

        {selectedMember && (
          <ProfileMember
            member={selectedMember}
            onAssignClick={() => setShowAssign(true)}
          />
        )}
      </Col>

      {/* Shared Assign modal */}
      <AssignCoachModal
        show={showAssign}
        onHide={() => setShowAssign(false)}
        presetCoach={selectedCoach}
        presetMember={selectedMember}
        onAssigned={onAssigned}
      />
    </Row>
  );
}
