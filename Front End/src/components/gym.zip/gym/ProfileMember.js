import React, { useEffect, useState, useMemo } from "react";
import { Card, Badge, Button, Table } from "react-bootstrap";

// ✅ corrected paths (services are in src/services)
import assignmentsService from "../../services/assignmentsService";
import idCardsService from "../../services/idCardsService";

import IdCardModal from "./IdCardModal";

const ageFrom = (d) => {
  if (!d) return "—";
  const bd = new Date(d);
  const a = new Date(Date.now() - bd.getTime()).getUTCFullYear() - 1970;
  return a;
};

export default function ProfileMember({ member, onAssignClick }) {
  const [assignments, setAssignments] = useState([]);
  const [showCard, setShowCard] = useState(false);
  const [activeCard, setActiveCard] = useState(null);

  // ✅ HOOK MUST BE BEFORE ANY RETURN
  const photoSrc = useMemo(() => {
    const raw =
      member?.photo_url ||
      member?.photo ||
      member?.image_url ||
      member?.member_photo_url;

    if (!raw) return null;
    if (raw.startsWith("http")) return raw;

    return `http://localhost:5000/${raw.replace(/^\/+/, "")}`;
  }, [member]);

  useEffect(() => {
    const loadAssignments = async () => {
      try {
        const rows = await assignmentsService.byMember(member.member_id);
        setAssignments(rows || []);
      } catch (err) {
        console.error("Failed to load assignments:", err);
        setAssignments([]);
      }
    };

    if (member?.member_id) loadAssignments();
  }, [member]);

  const openModalWith = (card) => {
    setActiveCard(card);
    setShowCard(true);
  };

  const handleGenerateIdCard = async () => {
    const payload = {
      role: "member",
      member_id: member.member_id,
      color: "#146b57",
      template: "verticalA",
    };

    try {
      const res = await idCardsService.generate(payload, { force: false });
      openModalWith(res.card);
    } catch (e) {
      if (e.code === "ALREADY_EXISTS" && e.card) {
        const c = e.card;

        const again = window.confirm(
          `This member already has an ID card.\n` +
            `Existing ID: ${c.sub_id}\nCreated: ${new Date(
              c.created_at
            ).toLocaleString()}\n\n` +
            `Generate a NEW ID card anyway?`
        );

        if (!again) {
          openModalWith(c);
          return;
        }

        try {
          const res2 = await idCardsService.generate(payload, { force: true });
          openModalWith(res2.card);
        } catch (err2) {
          console.error(err2);
          alert(err2.message || "Failed to generate ID card");
        }
      } else {
        console.error(e);
        alert(e.message || "Failed to generate ID card");
      }
    }
  };

  if (!member) return null;

  return (
    <>
      <Card className="border-0 shadow-sm">
        <Card.Header className="d-flex justify-content-between align-items-center">
          <div className="d-flex align-items-center">
            <div
              className="rounded me-2"
              style={{
                width: 56,
                height: 56,
                overflow: "hidden",
                background: "#eee",
              }}
            >
              {photoSrc ? (
                <img
                  src={photoSrc}
                  alt=""
                  style={{ width: "100%", height: "100%", objectFit: "cover" }}
                  onError={(e) => {
                    e.currentTarget.style.display = "none";
                  }}
                />
              ) : (
                <span
                  className="d-block text-center"
                  style={{ lineHeight: "56px" }}
                >
                  🙂
                </span>
              )}
            </div>

            <div>
              <h6 className="mb-0">{member.full_name}</h6>
              <small className="text-muted">
                {member.phone || member.email || ""}
              </small>
            </div>
          </div>

          <Badge bg={member.status === "Active" ? "primary" : "secondary"}>
            {member.status}
          </Badge>
        </Card.Header>

        <Card.Body>
          <div className="row g-2 mb-3">
            <div className="col-6">
              <strong>Age:</strong> {ageFrom(member.birth_date)}
            </div>
            <div className="col-6">
              <strong>Gender:</strong> {member.gender || "—"}
            </div>
            <div className="col-6">
              <strong>Height:</strong>{" "}
              {member.height_cm != null ? `${member.height_cm} cm` : "—"}
            </div>
            <div className="col-6">
              <strong>Weight:</strong>{" "}
              {member.weight_kg != null ? `${member.weight_kg} kg` : "—"}
            </div>
          </div>

          <div className="d-flex justify-content-between align-items-center mt-1 mb-2">
            <h6 className="mb-0">Coach History</h6>

            <div>
              <Button
                size="sm"
                className="me-2"
                variant="outline-success"
                onClick={handleGenerateIdCard}
              >
                Generate ID Card
              </Button>

              {onAssignClick && (
                <Button
                  size="sm"
                  variant="outline-primary"
                  onClick={onAssignClick}
                >
                  Assign Coach
                </Button>
              )}
            </div>
          </div>

          <Table size="sm" hover>
            <thead>
              <tr>
                <th>Coach ID</th>
                <th>Coach Name</th>
                <th>Specialty</th>
                <th>Start Date</th>
                <th>Status</th>
              </tr>
            </thead>

            <tbody>
              {assignments.map((a) => (
                <tr key={a.assignment_id}>
                  <td>{a.coach_id}</td>
                  <td>{a.coach_name}</td>
                  <td>{a.specialties}</td>
                  <td>{a.start_date?.slice(0, 10)}</td>
                  <td>
                    <Badge bg={a.status === "Active" ? "success" : "secondary"}>
                      {a.status}
                    </Badge>
                  </td>
                </tr>
              ))}

              {assignments.length === 0 && (
                <tr>
                  <td colSpan={5} className="text-muted">
                    No assignments
                  </td>
                </tr>
              )}
            </tbody>
          </Table>
        </Card.Body>
      </Card>

      <IdCardModal
        show={showCard}
        onHide={() => setShowCard(false)}
        card={activeCard}
      />
    </>
  );
}
