// Front_end/snp/src/components/gym/GymDashboard.js
import React, { useState } from "react";
import { Card, Tabs, Tab, Badge } from "react-bootstrap";
import GymSubscriptions from "./GymSubscriptions";
import GymDirectory from "./GymDirectory";
import GymMembersBoard from "./GymMembersBoard";
import AIGymPlanModal from "./AIGymPlanModal";
import GymPlansModal from "./GymPlansModal";

const theme = {
  headerGradient: "linear-gradient(90deg, #3b2a88 0%, #146b57 100%)",
  chipBg: "#efe7ff",
  chipText: "#3b2a88",
  tabActive: "#3b2a88",
  tabInactive: "#e9ecef",
  pageBg: "#f4f5f7",
};

const GymDashboard = () => {
  const [activeKey, setActiveKey] = useState("subscriptions");

  const [showAI, setShowAI] = useState(false);
  const [showPlans, setShowPlans] = useState(false);

  return (
    <div style={{ background: theme.pageBg, minHeight: "100%", padding: "12px" }}>
      <Card className="border-0 shadow-sm" style={{ borderRadius: 16 }}>
        {/* Header */}
        <Card.Header
          style={{
            background: theme.headerGradient,
            color: "#fff",
            borderTopLeftRadius: 16,
            borderTopRightRadius: 16,
          }}
        >
          <div className="d-flex justify-content-between align-items-center">
            <h4 className="mb-0">Gym Management Dashboard</h4>
            <Badge bg="light" text="dark">
              Admin View
            </Badge>
          </div>
        </Card.Header>

        {/* Tabs */}
        <Card.Body>
          <style>{`
            .gym-tabs .nav-link {
              font-weight: 600;
              border: 0 !important;
              margin-right: 6px;
              border-radius: 999px !important;
              padding: 8px 14px;
            }
            .gym-tabs .nav-link.active {
              background: ${theme.tabActive} !important;
              color: #fff !important;
            }
            .gym-tabs .nav-link:not(.active) {
              background: ${theme.tabInactive} !important;
              color: #2c2f34 !important;
            }
            .gym-chip {
              background: ${theme.chipBg};
              color: ${theme.chipText};
              border-radius: 999px;
              padding: 6px 12px;
              font-weight: 700;
            }
            .gym-content {
              background: #fff;
              border-radius: 12px;
              padding: 18px;
              box-shadow: 0 6px 16px rgba(0,0,0,0.06);
              position: relative;
              min-height: 500px;
            }
            .sub-actions {
              position: absolute;
              right: 18px;
              top: 18px;
              display: flex;
              gap: 10px;
              z-index: 10;
            }
            .sub-fab {
              border: none;
              border-radius: 999px;
              padding: 8px 14px;
              font-weight: 700;
              color: white;
              cursor: pointer;
              box-shadow: 0 8px 20px rgba(0,0,0,0.18);
              display: flex;
              align-items: center;
              gap: 8px;
              font-size: 14px;
            }
            .sub-fab.ai {
              background: linear-gradient(90deg, #ff0000ff 0%, #ffea00ff 100%);
            }
            .sub-fab.plans {
              background: linear-gradient(90deg, #0400ffff 0%, #fb2affff 100%);
            }
          `}</style>

          <div className="d-flex justify-content-between align-items-center mb-3">
            <div className="gym-chip">Start here: choose a tab</div>
          </div>

          <Tabs
            id="gym-tabs"
            activeKey={activeKey}
            onSelect={(k) => setActiveKey(k)}
            className="gym-tabs mb-3"
          >
            {/* Subscriptions */}
            <Tab eventKey="subscriptions" title="🏅 Subscriptions">
              <div className="gym-content">
                <div className="sub-actions">
                  <button
                    className="sub-fab plans"
                    onClick={() => setShowPlans(true)}
                    title="View Gym Plans"
                  >
                    📄 Gym Plans
                  </button>

                  <button
                    className="sub-fab ai"
                    onClick={() => setShowAI(true)}
                    title="Generate AI Plan"
                  >
                    🤖 AI Plan
                  </button>
                </div>

                <GymSubscriptions />
              </div>
            </Tab>

            {/* Coaches */}
            <Tab eventKey="coaches" title="👨‍🏫 Coaches">
              <div className="gym-content">
                {/* ✅ "More" button is now INSIDE GymDirectory header */}
                <GymDirectory />
              </div>
            </Tab>

            {/* Members */}
            <Tab eventKey="members" title="🧍 Members">
              <div className="gym-content">
                <GymMembersBoard />
              </div>
            </Tab>

            {/* Attendance */}
            <Tab eventKey="attendance" title="📅 Attendance">
              <div className="gym-content">
                <h5 className="mb-2">Attendance Tracker</h5>
                <p className="text-muted mb-0">
                  Record check-ins/check-outs and filter by date to see active vs inactive members.
                </p>
              </div>
            </Tab>

            {/* Progress */}
            <Tab eventKey="progress" title="💪 Progress">
              <div className="gym-content">
                <h5 className="mb-2">Progress Tracking</h5>
                <p className="text-muted mb-0">
                  Track weight, BMI, body fat %, goals, and (later) show charts.
                </p>
              </div>
            </Tab>
          </Tabs>
        </Card.Body>
      </Card>

      {/* Modals */}
      <AIGymPlanModal show={showAI} onHide={() => setShowAI(false)} />
      <GymPlansModal show={showPlans} onHide={() => setShowPlans(false)} />
    </div>
  );
};

export default GymDashboard;
